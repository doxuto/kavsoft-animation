//
//  MotionParallaxApp.swift
//  Shared
//
//  Created by Balaji on 23/11/21.
//

import SwiftUI

@main
struct MotionParallaxApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
