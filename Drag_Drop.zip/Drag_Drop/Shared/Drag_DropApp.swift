//
//  Drag_DropApp.swift
//  Shared
//
//  Created by Balaji on 26/03/22.
//

import SwiftUI

@main
struct Drag_DropApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
