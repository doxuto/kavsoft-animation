//
//  LiquidTransitionApp.swift
//  Shared
//
//  Created by Balaji on 08/03/22.
//

import SwiftUI

@main
struct LiquidTransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
