//
//  FluidBodyApp.swift
//  FluidBody
//
//  Created by Balaji on 29/10/22.
//

import SwiftUI

@main
struct FluidBodyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
