//
//  AnalyticsApp.swift
//  Shared
//
//  Created by Balaji on 01/10/21.
//

import SwiftUI

@main
struct AnalyticsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
