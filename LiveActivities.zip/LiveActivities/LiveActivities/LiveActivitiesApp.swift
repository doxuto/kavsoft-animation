//
//  LiveActivitiesApp.swift
//  LiveActivities
//
//  Created by Balaji on 28/07/22.
//

import SwiftUI

@main
struct LiveActivitiesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
