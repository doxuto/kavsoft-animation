//
//  InfiniteStackedCarouselApp.swift
//  Shared
//
//  Created by Balaji on 09/11/21.
//

import SwiftUI

@main
struct InfiniteStackedCarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
