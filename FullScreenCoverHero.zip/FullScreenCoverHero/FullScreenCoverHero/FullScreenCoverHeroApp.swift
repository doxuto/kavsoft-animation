//
//  FullScreenCoverHeroApp.swift
//  FullScreenCoverHero
//
//  Created by Balaji on 05/02/23.
//

import SwiftUI

@main
struct FullScreenCoverHeroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
