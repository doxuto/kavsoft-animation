//
//  AnimatedTabIconsApp.swift
//  AnimatedTabIcons
//
//  Created by Balaji on 02/08/22.
//

import SwiftUI

@main
struct AnimatedTabIconsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
