//
//  Responsive_UI_NewApp.swift
//  Responsive_UI_New
//
//  Created by Balaji on 03/09/22.
//

import SwiftUI

@main
struct Responsive_UI_NewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
