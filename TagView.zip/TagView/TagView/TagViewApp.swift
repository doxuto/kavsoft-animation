//
//  TagViewApp.swift
//  TagView
//
//  Created by Balaji on 01/08/23.
//

import SwiftUI

@main
struct TagViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
