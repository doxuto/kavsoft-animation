//
//  ContentView.swift
//  Maps_iOS 17
//
//  Created by Balaji on 08/06/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
