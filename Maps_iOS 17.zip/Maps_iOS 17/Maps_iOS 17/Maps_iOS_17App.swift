//
//  Maps_iOS_17App.swift
//  Maps_iOS 17
//
//  Created by Balaji on 08/06/23.
//

import SwiftUI

@main
struct Maps_iOS_17App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
