//
//  TaggingApp.swift
//  Shared
//
//  Created by Balaji on 07/10/21.
//

import SwiftUI

@main
struct TaggingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
