//
//  GlassMorphismNewApp.swift
//  GlassMorphismNew
//
//  Created by Balaji on 26/08/22.
//

import SwiftUI

@main
struct GlassMorphismNewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
