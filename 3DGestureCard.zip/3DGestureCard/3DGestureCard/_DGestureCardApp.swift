//
//  _DGestureCardApp.swift
//  3DGestureCard
//
//  Created by Balaji on 14/11/22.
//

import SwiftUI

@main
struct _DGestureCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
