//
//  MatrixRainEffectApp.swift
//  Shared
//
//  Created by Balaji on 04/02/22.
//

import SwiftUI

@main
struct MatrixRainEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
