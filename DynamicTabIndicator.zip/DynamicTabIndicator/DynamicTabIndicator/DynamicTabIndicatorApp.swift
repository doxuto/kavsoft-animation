//
//  DynamicTabIndicatorApp.swift
//  DynamicTabIndicator
//
//  Created by Balaji on 13/07/22.
//

import SwiftUI

@main
struct DynamicTabIndicatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
