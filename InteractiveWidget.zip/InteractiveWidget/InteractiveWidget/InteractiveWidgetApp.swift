//
//  InteractiveWidgetApp.swift
//  InteractiveWidget
//
//  Created by Balaji on 11/06/23.
//

import SwiftUI

@main
struct InteractiveWidgetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
