//
//  ShaderExampleApp.swift
//  ShaderExample
//
//  Created by Balaji on 17/06/23.
//

import SwiftUI

@main
struct ShaderExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
