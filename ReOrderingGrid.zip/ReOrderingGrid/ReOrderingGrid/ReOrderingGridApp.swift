//
//  ReOrderingGridApp.swift
//  ReOrderingGrid
//
//  Created by Balaji on 01/07/23.
//

import SwiftUI

@main
struct ReOrderingGridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
