//
//  QuizGameApp.swift
//  Shared
//
//  Created by Balaji on 13/02/22.
//

import SwiftUI

@main
struct QuizGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
