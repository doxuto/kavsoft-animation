//
//  AnimationChallenge3App.swift
//  Shared
//
//  Created by Balaji on 29/03/22.
//

import SwiftUI

@main
struct AnimationChallenge3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
