//
//  ContentView.swift
//  ShowcaseView
//
//  Created by Balaji on 11/05/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
