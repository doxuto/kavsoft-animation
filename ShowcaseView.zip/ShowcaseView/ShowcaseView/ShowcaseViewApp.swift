//
//  ShowcaseViewApp.swift
//  ShowcaseView
//
//  Created by Balaji on 11/05/23.
//

import SwiftUI

@main
struct ShowcaseViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
