//
//  ContentView.swift
//  GlassMorphismCard
//
//  Created by Balaji on 24/06/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
