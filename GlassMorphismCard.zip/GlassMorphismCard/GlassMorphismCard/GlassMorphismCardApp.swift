//
//  GlassMorphismCardApp.swift
//  GlassMorphismCard
//
//  Created by Balaji on 24/06/23.
//

import SwiftUI

@main
struct GlassMorphismCardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
