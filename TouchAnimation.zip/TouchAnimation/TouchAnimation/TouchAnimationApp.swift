//
//  TouchAnimationApp.swift
//  TouchAnimation
//
//  Created by Balaji on 14/08/22.
//

import SwiftUI

@main
struct TouchAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
