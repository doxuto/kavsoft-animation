//
//  PageCurlSwipeApp.swift
//  PageCurlSwipe
//
//  Created by Balaji on 22/03/23.
//

import SwiftUI

@main
struct PageCurlSwipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
