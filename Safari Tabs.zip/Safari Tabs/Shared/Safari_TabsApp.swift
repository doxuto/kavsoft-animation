//
//  Safari_TabsApp.swift
//  Shared
//
//  Created by Balaji on 23/09/21.
//

import SwiftUI

@main
struct Safari_TabsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
