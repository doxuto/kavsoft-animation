//
//  BookAppAnimationApp.swift
//  BookAppAnimation
//
//  Created by Balaji on 20/10/22.
//

import SwiftUI

@main
struct BookAppAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
