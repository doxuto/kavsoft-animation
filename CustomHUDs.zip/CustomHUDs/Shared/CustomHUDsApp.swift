//
//  CustomHUDsApp.swift
//  Shared
//
//  Created by Balaji on 30/10/21.
//

import SwiftUI

@main
struct CustomHUDsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
