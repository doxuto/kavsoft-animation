//
//  LockSwiftUIViewApp.swift
//  LockSwiftUIView
//
//  Created by Balaji Venkatesh on 19/10/23.
//

import SwiftUI

@main
struct LockSwiftUIViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
