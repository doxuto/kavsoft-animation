//
//  AppleMusicBottomSheetApp.swift
//  AppleMusicBottomSheet
//
//  Created by Balaji on 18/03/23.
//

import SwiftUI

@main
struct AppleMusicBottomSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
