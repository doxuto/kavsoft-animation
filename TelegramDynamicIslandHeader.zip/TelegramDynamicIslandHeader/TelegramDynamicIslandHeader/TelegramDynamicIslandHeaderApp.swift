//
//  TelegramDynamicIslandHeaderApp.swift
//  TelegramDynamicIslandHeader
//
//  Created by Balaji on 28/05/23.
//

import SwiftUI

@main
struct TelegramDynamicIslandHeaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
