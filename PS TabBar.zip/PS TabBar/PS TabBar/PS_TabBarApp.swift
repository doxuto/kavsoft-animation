//
//  PS_TabBarApp.swift
//  PS TabBar
//
//  Created by Balaji on 16/02/23.
//

import SwiftUI

@main
struct PS_TabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
