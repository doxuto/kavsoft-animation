//
//  SpotifyHeaderAnimationApp.swift
//  SpotifyHeaderAnimation
//
//  Created by Balaji on 02/12/22.
//

import SwiftUI

@main
struct SpotifyHeaderAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
