//
//  iPhonePopOversApp.swift
//  iPhonePopOvers
//
//  Created by Balaji on 21/01/23.
//

import SwiftUI

@main
struct iPhonePopOversApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
