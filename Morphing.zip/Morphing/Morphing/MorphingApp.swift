//
//  MorphingApp.swift
//  Morphing
//
//  Created by Balaji on 18/09/22.
//

import SwiftUI

@main
struct MorphingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
