//
//  LinkPreviewSwiftUIApp.swift
//  Shared
//
//  Created by Balaji on 04/12/21.
//

import SwiftUI

@main
struct LinkPreviewSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
