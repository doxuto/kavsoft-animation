//
//  Rolling_CounterApp.swift
//  Rolling Counter
//
//  Created by Balaji on 08/07/22.
//

import SwiftUI

@main
struct Rolling_CounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
