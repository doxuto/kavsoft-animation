//
//  AnimatedButtonApp.swift
//  AnimatedButton
//
//  Created by Balaji on 16/08/23.
//

import SwiftUI

@main
struct AnimatedButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
