//
//  CustomTransitionApp.swift
//  Shared
//
//  Created by Balaji on 23/02/22.
//

import SwiftUI

@main
struct CustomTransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
