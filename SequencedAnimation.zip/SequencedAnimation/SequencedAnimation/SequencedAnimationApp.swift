//
//  SequencedAnimationApp.swift
//  SequencedAnimation
//
//  Created by Balaji on 03/11/22.
//

import SwiftUI

@main
struct SequencedAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
