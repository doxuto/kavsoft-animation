//
//  ResponsiveUIApp.swift
//  Shared
//
//  Created by Balaji on 04/03/22.
//

import SwiftUI

@main
struct ResponsiveUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
