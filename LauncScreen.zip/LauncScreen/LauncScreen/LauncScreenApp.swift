//
//  LauncScreenApp.swift
//  LauncScreen
//
//  Created by Balaji on 01/07/22.
//

import SwiftUI

@main
struct LauncScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
