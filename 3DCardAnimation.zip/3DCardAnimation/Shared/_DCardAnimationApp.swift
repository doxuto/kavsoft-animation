//
//  _DCardAnimationApp.swift
//  Shared
//
//  Created by Balaji on 21/03/22.
//

import SwiftUI

@main
struct _DCardAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
