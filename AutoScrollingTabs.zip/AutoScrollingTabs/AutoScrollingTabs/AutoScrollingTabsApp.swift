//
//  AutoScrollingTabsApp.swift
//  AutoScrollingTabs
//
//  Created by Balaji on 13/02/23.
//

import SwiftUI

@main
struct AutoScrollingTabsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
