//
//  SwipeHiddenHeaderApp.swift
//  SwipeHiddenHeader
//
//  Created by Balaji on 20/07/22.
//

import SwiftUI

@main
struct SwipeHiddenHeaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
