//
//  ComplexMatchedGeometryApp.swift
//  ComplexMatchedGeometry
//
//  Created by Balaji on 23/08/22.
//

import SwiftUI

@main
struct ComplexMatchedGeometryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
