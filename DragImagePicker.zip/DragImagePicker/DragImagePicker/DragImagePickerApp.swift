//
//  DragImagePickerApp.swift
//  DragImagePicker
//
//  Created by Balaji on 18/08/23.
//

import SwiftUI

@main
struct DragImagePickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
