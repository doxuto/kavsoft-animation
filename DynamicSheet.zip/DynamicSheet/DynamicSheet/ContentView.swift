//
//  ContentView.swift
//  DynamicSheet
//
//  Created by Balaji on 07/08/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
