//
//  DynamicSheetApp.swift
//  DynamicSheet
//
//  Created by Balaji on 07/08/23.
//

import SwiftUI

@main
struct DynamicSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
