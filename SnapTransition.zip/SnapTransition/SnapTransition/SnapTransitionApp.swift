//
//  SnapTransitionApp.swift
//  SnapTransition
//
//  Created by Balaji on 18/01/23.
//

import SwiftUI

@main
struct SnapTransitionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
