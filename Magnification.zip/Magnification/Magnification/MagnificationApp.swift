//
//  MagnificationApp.swift
//  Magnification
//
//  Created by Balaji on 27/11/22.
//

import SwiftUI

@main
struct MagnificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
