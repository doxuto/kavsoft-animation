//
//  CustomTFKeyboardApp.swift
//  CustomTFKeyboard
//
//  Created by Balaji on 25/02/23.
//

import SwiftUI

@main
struct CustomTFKeyboardApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
