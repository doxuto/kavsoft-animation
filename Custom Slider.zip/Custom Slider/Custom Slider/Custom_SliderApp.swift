//
//  Custom_SliderApp.swift
//  Custom Slider
//
//  Created by Balaji Venkatesh on 20/09/23.
//

import SwiftUI

@main
struct Custom_SliderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
