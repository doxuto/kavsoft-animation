//
//  Infinite_CarouselApp.swift
//  Infinite Carousel
//
//  Created by Balaji on 27/03/23.
//

import SwiftUI

@main
struct Infinite_CarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
