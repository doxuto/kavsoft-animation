//
//  FoodDeliveryAppApp.swift
//  FoodDeliveryApp
//
//  Created by Balaji on 07/09/22.
//

import SwiftUI

@main
struct FoodDeliveryAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
