//
//  HeartParticle.swift
//  HeartAnimation
//
//  Created by Balaji Venkatesh on 23/09/23.
//

import SwiftUI

struct HeartParticle: Identifiable {
    var id: UUID = .init()
}
