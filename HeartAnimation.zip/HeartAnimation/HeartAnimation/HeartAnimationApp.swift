//
//  HeartAnimationApp.swift
//  HeartAnimation
//
//  Created by Balaji Venkatesh on 22/09/23.
//

import SwiftUI

@main
struct HeartAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
