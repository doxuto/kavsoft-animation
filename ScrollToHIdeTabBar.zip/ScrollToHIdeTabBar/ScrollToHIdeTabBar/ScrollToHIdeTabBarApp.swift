//
//  ScrollToHIdeTabBarApp.swift
//  ScrollToHIdeTabBar
//
//  Created by Balaji on 30/07/23.
//

import SwiftUI

@main
struct ScrollToHIdeTabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
