//
//  ReelsCameraApp.swift
//  Shared
//
//  Created by Balaji on 06/04/22.
//

import SwiftUI

@main
struct ReelsCameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
