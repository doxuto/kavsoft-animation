//
//  MaterialCarouselApp.swift
//  MaterialCarousel
//
//  Created by Balaji on 27/06/23.
//

import SwiftUI

@main
struct MaterialCarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
