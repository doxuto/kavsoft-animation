//
//  iMessageCardSwipeApp.swift
//  iMessageCardSwipe
//
//  Created by Balaji on 01/10/22.
//

import SwiftUI

@main
struct iMessageCardSwipeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
