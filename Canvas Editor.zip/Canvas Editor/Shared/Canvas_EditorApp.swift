//
//  Canvas_EditorApp.swift
//  Shared
//
//  Created by Balaji on 04/05/22.
//

import SwiftUI

@main
struct Canvas_EditorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
