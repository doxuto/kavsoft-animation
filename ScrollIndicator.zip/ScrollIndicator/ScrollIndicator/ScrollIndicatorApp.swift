//
//  ScrollIndicatorApp.swift
//  ScrollIndicator
//
//  Created by Balaji on 16/10/22.
//

import SwiftUI

@main
struct ScrollIndicatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
