//
//  WalletAnimationApp.swift
//  Shared
//
//  Created by Balaji on 24/02/22.
//

import SwiftUI

@main
struct WalletAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
