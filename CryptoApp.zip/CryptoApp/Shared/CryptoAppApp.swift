//
//  CryptoAppApp.swift
//  Shared
//
//  Created by Balaji on 10/04/22.
//

import SwiftUI

@main
struct CryptoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
