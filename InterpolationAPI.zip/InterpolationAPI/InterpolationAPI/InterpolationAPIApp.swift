//
//  InterpolationAPIApp.swift
//  InterpolationAPI
//
//  Created by Balaji on 18/08/22.
//

import SwiftUI

@main
struct InterpolationAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
