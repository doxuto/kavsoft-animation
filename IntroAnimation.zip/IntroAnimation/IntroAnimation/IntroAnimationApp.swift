//
//  IntroAnimationApp.swift
//  IntroAnimation
//
//  Created by Balaji on 14/10/22.
//

import SwiftUI

@main
struct IntroAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
