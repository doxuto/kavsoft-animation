//
//  BreatheAnimationApp.swift
//  BreatheAnimation
//
//  Created by Balaji on 25/07/22.
//

import SwiftUI

@main
struct BreatheAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
