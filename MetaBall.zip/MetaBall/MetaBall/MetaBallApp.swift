//
//  MetaBallApp.swift
//  MetaBall
//
//  Created by Balaji on 21/09/22.
//

import SwiftUI

@main
struct MetaBallApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
