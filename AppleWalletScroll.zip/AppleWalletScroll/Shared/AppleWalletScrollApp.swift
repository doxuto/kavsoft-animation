//
//  AppleWalletScrollApp.swift
//  Shared
//
//  Created by Balaji on 17/02/22.
//

import SwiftUI

@main
struct AppleWalletScrollApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
