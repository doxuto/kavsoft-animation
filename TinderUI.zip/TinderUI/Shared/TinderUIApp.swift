//
//  TinderUIApp.swift
//  Shared
//
//  Created by Balaji on 07/12/21.
//

import SwiftUI

@main
struct TinderUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
