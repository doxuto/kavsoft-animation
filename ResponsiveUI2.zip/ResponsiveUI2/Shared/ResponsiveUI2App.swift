//
//  ResponsiveUI2App.swift
//  Shared
//
//  Created by Balaji on 03/06/22.
//

import SwiftUI

@main
struct ResponsiveUI2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
