//
//  TwitterShapeAnimationApp.swift
//  Shared
//
//  Created by Balaji on 01/11/21.
//

import SwiftUI

@main
struct TwitterShapeAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
