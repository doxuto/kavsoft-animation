//
//  iOS16LockScreenApp.swift
//  iOS16LockScreen
//
//  Created by Balaji on 10/08/22.
//

import SwiftUI

@main
struct iOS16LockScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
