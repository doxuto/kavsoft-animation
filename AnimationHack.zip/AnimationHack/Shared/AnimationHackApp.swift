//
//  AnimationHackApp.swift
//  Shared
//
//  Created by Balaji on 26/05/22.
//

import SwiftUI

@main
struct AnimationHackApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
