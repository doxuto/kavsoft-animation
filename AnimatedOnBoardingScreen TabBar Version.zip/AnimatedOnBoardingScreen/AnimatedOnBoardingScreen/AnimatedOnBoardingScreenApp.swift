//
//  AnimatedOnBoardingScreenApp.swift
//  AnimatedOnBoardingScreen
//
//  Created by Balaji on 17/12/22.
//

import SwiftUI

@main
struct AnimatedOnBoardingScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
