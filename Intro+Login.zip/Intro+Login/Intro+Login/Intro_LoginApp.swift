//
//  Intro_LoginApp.swift
//  Intro+Login
//
//  Created by Balaji on 29/03/23.
//

import SwiftUI

@main
struct Intro_LoginApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
