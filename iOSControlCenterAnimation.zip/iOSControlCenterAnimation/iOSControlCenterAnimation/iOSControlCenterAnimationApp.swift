//
//  iOSControlCenterAnimationApp.swift
//  iOSControlCenterAnimation
//
//  Created by Balaji on 01/01/23.
//

import SwiftUI

@main
struct iOSControlCenterAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
