//
//  Scrollable_MenuApp.swift
//  Shared
//
//  Created by Balaji on 23/10/21.
//

import SwiftUI

@main
struct Scrollable_MenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
