//
//  TripAdvisorSpalshApp.swift
//  Shared
//
//  Created by Balaji on 18/12/21.
//

import SwiftUI

@main
struct TripAdvisorSpalshApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
