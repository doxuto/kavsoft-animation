//
//  BoomerangCardsApp.swift
//  BoomerangCards
//
//  Created by Balaji on 09/10/22.
//

import SwiftUI

@main
struct BoomerangCardsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
