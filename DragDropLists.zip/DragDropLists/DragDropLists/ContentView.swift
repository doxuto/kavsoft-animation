//
//  ContentView.swift
//  DragDropLists
//
//  Created by Balaji on 18/07/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
