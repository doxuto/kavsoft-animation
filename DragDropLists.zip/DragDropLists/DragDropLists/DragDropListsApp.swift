//
//  DragDropListsApp.swift
//  DragDropLists
//
//  Created by Balaji on 18/07/23.
//

import SwiftUI

@main
struct DragDropListsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
