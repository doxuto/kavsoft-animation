//
//  SwipeToHideNavBarApp.swift
//  SwipeToHideNavBar
//
//  Created by Balaji Venkatesh on 09/09/23.
//

import SwiftUI

@main
struct SwipeToHideNavBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
