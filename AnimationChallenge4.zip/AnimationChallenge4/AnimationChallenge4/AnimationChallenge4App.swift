//
//  AnimationChallenge4App.swift
//  AnimationChallenge4
//
//  Created by Balaji on 14/06/22.
//

import SwiftUI

@main
struct AnimationChallenge4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
