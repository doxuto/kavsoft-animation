//
//  CryptoLiveApp.swift
//  CryptoLive
//
//  Created by Balaji on 23/11/22.
//

import SwiftUI

@main
struct CryptoLiveApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
