//
//  OnBoardingAnimationApp.swift
//  Shared
//
//  Created by Balaji on 27/08/21.
//

import SwiftUI

@main
struct OnBoardingAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
