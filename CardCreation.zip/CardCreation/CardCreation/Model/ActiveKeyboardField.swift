//
//  ActiveKeyboardField.swift
//  CardCreation
//
//  Created by Balaji on 03/04/23.
//

import SwiftUI

enum ActiveKeyboardField {
    case cardNumber
    case expirationDate
    case cvv
    case cardHolderName
}
