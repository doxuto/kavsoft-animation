//
//  CardCreationApp.swift
//  CardCreation
//
//  Created by Balaji on 03/04/23.
//

import SwiftUI

@main
struct CardCreationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
