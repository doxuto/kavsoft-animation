//
//  PizzaAnimationApp.swift
//  PizzaAnimation
//
//  Created by Balaji on 02/07/22.
//

import SwiftUI

@main
struct PizzaAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
