//
//  CustomMenu_SideApp.swift
//  Shared
//
//  Created by Balaji on 10/12/21.
//

import SwiftUI

@main
struct CustomMenu_SideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
