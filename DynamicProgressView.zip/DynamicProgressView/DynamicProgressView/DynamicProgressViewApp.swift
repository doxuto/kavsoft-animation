//
//  DynamicProgressViewApp.swift
//  DynamicProgressView
//
//  Created by Balaji on 03/10/22.
//

import SwiftUI

@main
struct DynamicProgressViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
