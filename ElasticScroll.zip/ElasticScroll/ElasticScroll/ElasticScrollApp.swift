//
//  ElasticScrollApp.swift
//  ElasticScroll
//
//  Created by Balaji on 28/05/23.
//

import SwiftUI

@main
struct ElasticScrollApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
