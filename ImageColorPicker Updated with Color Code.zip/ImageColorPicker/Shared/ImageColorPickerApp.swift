//
//  ImageColorPickerApp.swift
//  Shared
//
//  Created by Balaji on 29/01/22.
//

import SwiftUI

@main
struct ImageColorPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
