//
//  NetflixSplashScreenApp.swift
//  Shared
//
//  Created by Balaji on 04/10/21.
//

import SwiftUI

@main
struct NetflixSplashScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
