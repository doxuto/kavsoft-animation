//
//  AnimatedSFTabBarApp.swift
//  AnimatedSFTabBar
//
//  Created by Balaji Venkatesh on 31/08/23.
//

import SwiftUI

@main
struct AnimatedSFTabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
