//
//  AutoOtpTFApp.swift
//  AutoOtpTF
//
//  Created by Balaji on 22/12/22.
//

import SwiftUI

@main
struct AutoOtpTFApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
