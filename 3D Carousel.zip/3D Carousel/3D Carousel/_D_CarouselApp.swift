//
//  _D_CarouselApp.swift
//  3D Carousel
//
//  Created by Balaji on 27/10/22.
//

import SwiftUI

@main
struct _D_CarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
