//
//  NavigationHeroAnimationApp.swift
//  NavigationHeroAnimation
//
//  Created by Balaji on 19/07/23.
//

import SwiftUI

@main
struct NavigationHeroAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
