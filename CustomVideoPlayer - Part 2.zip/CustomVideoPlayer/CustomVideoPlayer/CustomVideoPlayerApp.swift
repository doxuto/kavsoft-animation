//
//  CustomVideoPlayerApp.swift
//  CustomVideoPlayer
//
//  Created by Balaji on 16/04/23.
//

import SwiftUI

@main
struct CustomVideoPlayerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
