//
//  ContentView.swift
//  SegmentedControlAnimation
//
//  Created by Balaji on 31/01/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
