//
//  SegmentedControlAnimationApp.swift
//  SegmentedControlAnimation
//
//  Created by Balaji on 31/01/23.
//

import SwiftUI

@main
struct SegmentedControlAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
