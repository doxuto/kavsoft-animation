//
//  Tab.swift
//  SegmentedControlAnimation
//
//  Created by Balaji on 31/01/23.
//

import SwiftUI

/// - Enum Tab Cases
enum Tab: String{
    case photo = "Photo"
    case video = "Video"
}
