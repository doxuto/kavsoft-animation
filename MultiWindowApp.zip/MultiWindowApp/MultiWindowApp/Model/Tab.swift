//
//  Tab.swift
//  MultiWindowApp
//
//  Created by Balaji on 02/11/22.
//

import SwiftUI

// MARK: Tab Model
struct Tab: Identifiable,Hashable,Codable {
    var id: String = UUID().uuidString
    // MARK: YOUR PROPERTIES GOES HERE
}
