//
//  MapsBottomSheetApp.swift
//  MapsBottomSheet
//
//  Created by Balaji on 18/06/22.
//

import SwiftUI

@main
struct MapsBottomSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
