//
//  SideMenuWithCustomShapeApp.swift
//  Shared
//
//  Created by Balaji on 13/10/21.
//

import SwiftUI

@main
struct SideMenuWithCustomShapeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
