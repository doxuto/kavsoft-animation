//
//  CardAnimationApp.swift
//  CardAnimation
//
//  Created by Balaji on 04/05/23.
//

import SwiftUI

@main
struct CardAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
