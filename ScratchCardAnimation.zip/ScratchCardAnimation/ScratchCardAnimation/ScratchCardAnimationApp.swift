//
//  ScratchCardAnimationApp.swift
//  ScratchCardAnimation
//
//  Created by Balaji on 23/07/22.
//

import SwiftUI

@main
struct ScratchCardAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
