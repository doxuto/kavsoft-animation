//
//  ResizableHeaderApp.swift
//  ResizableHeader
//
//  Created by Balaji on 02/05/23.
//

import SwiftUI

@main
struct ResizableHeaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
