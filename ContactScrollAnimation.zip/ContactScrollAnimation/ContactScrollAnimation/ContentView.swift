//
//  ContentView.swift
//  ContactScrollAnimation
//
//  Created by Balaji on 23/09/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
