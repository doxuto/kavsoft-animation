//
//  ContactScrollAnimationApp.swift
//  ContactScrollAnimation
//
//  Created by Balaji on 23/09/22.
//

import SwiftUI

@main
struct ContactScrollAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
