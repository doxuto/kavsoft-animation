//
//  FullScreenPopApp.swift
//  FullScreenPop
//
//  Created by Balaji Venkatesh on 06/10/23.
//

import SwiftUI

@main
struct FullScreenPopApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
