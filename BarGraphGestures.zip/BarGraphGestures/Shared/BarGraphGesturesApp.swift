//
//  BarGraphGesturesApp.swift
//  Shared
//
//  Created by Balaji on 02/11/21.
//

import SwiftUI

@main
struct BarGraphGesturesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
