//
//  PlantAppApp.swift
//  PlantApp
//
//  Created by Balaji on 12/10/22.
//

import SwiftUI

@main
struct PlantAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
