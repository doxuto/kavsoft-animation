//
//  BlurredSheetApp.swift
//  BlurredSheet
//
//  Created by Balaji on 14/12/22.
//

import SwiftUI

@main
struct BlurredSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
