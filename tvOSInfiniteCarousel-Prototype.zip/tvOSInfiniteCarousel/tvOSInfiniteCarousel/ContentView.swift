//
//  ContentView.swift
//  tvOSInfiniteCarousel
//
//  Created by Balaji on 07/04/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        InfiniteCarousel()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
