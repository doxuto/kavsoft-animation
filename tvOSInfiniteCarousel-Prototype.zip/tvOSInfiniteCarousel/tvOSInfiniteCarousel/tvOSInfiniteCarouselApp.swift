//
//  tvOSInfiniteCarouselApp.swift
//  tvOSInfiniteCarousel
//
//  Created by Balaji on 07/04/23.
//

import SwiftUI

@main
struct tvOSInfiniteCarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
