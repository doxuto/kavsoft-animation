//
//  PizzaChallengeApp.swift
//  Shared
//
//  Created by Balaji on 11/12/21.
//

import SwiftUI

@main
struct PizzaChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
