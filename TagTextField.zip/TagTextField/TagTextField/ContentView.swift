//
//  ContentView.swift
//  TagTextField
//
//  Created by Balaji Venkatesh on 13/09/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}


#Preview {
    ContentView()
}
