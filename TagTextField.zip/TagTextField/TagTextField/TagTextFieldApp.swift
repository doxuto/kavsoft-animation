//
//  TagTextFieldApp.swift
//  TagTextField
//
//  Created by Balaji Venkatesh on 13/09/23.
//

import SwiftUI

@main
struct TagTextFieldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
