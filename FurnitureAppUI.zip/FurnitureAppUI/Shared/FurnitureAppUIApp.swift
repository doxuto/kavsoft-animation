//
//  FurnitureAppUIApp.swift
//  Shared
//
//  Created by Balaji on 28/05/22.
//

import SwiftUI

@main
struct FurnitureAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
