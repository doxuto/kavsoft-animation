//
//  SkeletonSplashScreenApp.swift
//  Shared
//
//  Created by Balaji on 18/02/22.
//

import SwiftUI

@main
struct SkeletonSplashScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
