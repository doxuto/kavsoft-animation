//
//  ContentView.swift
//  Shared
//
//  Created by Balaji on 18/02/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        GameOverScreen()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
