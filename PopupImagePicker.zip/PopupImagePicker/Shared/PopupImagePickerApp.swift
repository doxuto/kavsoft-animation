//
//  PopupImagePickerApp.swift
//  Shared
//
//  Created by Balaji on 24/05/22.
//

import SwiftUI

@main
struct PopupImagePickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
