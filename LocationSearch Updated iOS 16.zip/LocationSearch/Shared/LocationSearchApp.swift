//
//  LocationSearchApp.swift
//  Shared
//
//  Created by Balaji on 20/04/22.
//

import SwiftUI

@main
struct LocationSearchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
