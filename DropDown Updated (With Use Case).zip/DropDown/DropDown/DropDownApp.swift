//
//  DropDownApp.swift
//  DropDown
//
//  Created by Balaji on 07/01/23.
//

import SwiftUI

@main
struct DropDownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
