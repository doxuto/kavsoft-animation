//
//  GooeyShareButtonApp.swift
//  GooeyShareButton
//
//  Created by Balaji on 16/05/23.
//

import SwiftUI

@main
struct GooeyShareButtonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
