//
//  ParallaxCardsApp.swift
//  ParallaxCards
//
//  Created by Balaji on 11/07/22.
//

import SwiftUI

@main
struct ParallaxCardsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
