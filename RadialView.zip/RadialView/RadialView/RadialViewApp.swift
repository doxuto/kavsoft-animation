//
//  RadialViewApp.swift
//  RadialView
//
//  Created by Balaji on 24/07/23.
//

import SwiftUI

@main
struct RadialViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
