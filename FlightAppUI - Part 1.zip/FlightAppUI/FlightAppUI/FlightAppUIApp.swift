//
//  FlightAppUIApp.swift
//  FlightAppUI
//
//  Created by Balaji on 24/11/22.
//

import SwiftUI

@main
struct FlightAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
