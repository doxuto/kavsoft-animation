//
//  ContentView.swift
//  TransparentBlur
//
//  Created by Balaji on 21/06/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
