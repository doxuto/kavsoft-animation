//
//  TransparentBlurApp.swift
//  TransparentBlur
//
//  Created by Balaji on 21/06/23.
//

import SwiftUI

@main
struct TransparentBlurApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
