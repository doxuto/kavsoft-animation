//
//  TagsApp.swift
//  Tags
//
//  Created by Balaji on 08/06/22.
//

import SwiftUI

@main
struct TagsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
