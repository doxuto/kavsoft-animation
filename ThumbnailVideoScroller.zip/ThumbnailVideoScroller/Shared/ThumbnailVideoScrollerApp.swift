//
//  ThumbnailVideoScrollerApp.swift
//  Shared
//
//  Created by Balaji on 20/02/22.
//

import SwiftUI

@main
struct ThumbnailVideoScrollerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
