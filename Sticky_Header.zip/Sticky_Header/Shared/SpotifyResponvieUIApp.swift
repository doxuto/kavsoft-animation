//
//  SpotifyResponvieUIApp.swift
//  Shared
//
//  Created by Balaji on 14/03/22.
//

import SwiftUI

@main
struct SpotifyResponvieUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
