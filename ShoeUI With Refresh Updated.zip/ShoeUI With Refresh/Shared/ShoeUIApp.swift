//
//  ShoeUIApp.swift
//  Shared
//
//  Created by Balaji on 30/08/21.
//

import SwiftUI

@main
struct ShoeUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
