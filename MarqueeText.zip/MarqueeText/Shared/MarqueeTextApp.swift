//
//  MarqueeTextApp.swift
//  Shared
//
//  Created by Balaji on 26/01/22.
//

import SwiftUI

@main
struct MarqueeTextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
