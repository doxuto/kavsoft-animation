//
//  ProgressHeroEffectApp.swift
//  ProgressHeroEffect
//
//  Created by Balaji Venkatesh on 13/10/23.
//

import SwiftUI

@main
struct ProgressHeroEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
