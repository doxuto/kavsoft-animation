//
//  AppStoreAnimationApp.swift
//  Shared
//
//  Created by Balaji on 04/04/22.
//

import SwiftUI

@main
struct AppStoreAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
