//
//  SwiftChartsApp.swift
//  SwiftCharts
//
//  Created by Balaji on 11/06/22.
//

import SwiftUI

@main
struct SwiftChartsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
