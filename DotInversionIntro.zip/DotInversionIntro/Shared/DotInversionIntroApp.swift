//
//  DotInversionIntroApp.swift
//  Shared
//
//  Created by Balaji on 26/10/21.
//

import SwiftUI

@main
struct DotInversionIntroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
