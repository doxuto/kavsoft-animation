//
//  TaskPlannerApp.swift
//  TaskPlanner
//
//  Created by Balaji on 04/01/23.
//

import SwiftUI

@main
struct TaskPlannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
