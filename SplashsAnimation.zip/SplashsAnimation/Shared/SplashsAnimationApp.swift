//
//  SplashsAnimationApp.swift
//  Shared
//
//  Created by Balaji on 17/10/21.
//

import SwiftUI

@main
struct SplashsAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
