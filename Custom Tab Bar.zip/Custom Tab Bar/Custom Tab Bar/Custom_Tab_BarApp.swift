//
//  Custom_Tab_BarApp.swift
//  Custom Tab Bar
//
//  Created by Balaji on 08/05/23.
//

import SwiftUI

@main
struct Custom_Tab_BarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
