//
//  KeyframesApp.swift
//  Keyframes
//
//  Created by Balaji on 07/06/23.
//

import SwiftUI

@main
struct KeyframesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
