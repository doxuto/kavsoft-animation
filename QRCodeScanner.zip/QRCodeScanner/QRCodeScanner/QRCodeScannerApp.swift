//
//  QRCodeScannerApp.swift
//  QRCodeScanner
//
//  Created by Balaji on 08/04/23.
//

import SwiftUI

@main
struct QRCodeScannerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
