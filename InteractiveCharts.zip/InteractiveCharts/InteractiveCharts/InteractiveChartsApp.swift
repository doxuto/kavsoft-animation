//
//  InteractiveChartsApp.swift
//  InteractiveCharts
//
//  Created by Balaji on 12/06/23.
//

import SwiftUI

@main
struct InteractiveChartsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
