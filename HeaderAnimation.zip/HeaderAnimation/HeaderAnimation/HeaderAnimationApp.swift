//
//  HeaderAnimationApp.swift
//  HeaderAnimation
//
//  Created by Balaji on 19/11/22.
//

import SwiftUI

@main
struct HeaderAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
