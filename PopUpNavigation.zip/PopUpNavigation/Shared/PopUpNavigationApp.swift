//
//  PopUpNavigationApp.swift
//  Shared
//
//  Created by Balaji on 17/01/22.
//

import SwiftUI

@main
struct PopUpNavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
