//
//  ShimmerTextApp.swift
//  ShimmerText
//
//  Created by Balaji on 15/03/23.
//

import SwiftUI

@main
struct ShimmerTextApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
