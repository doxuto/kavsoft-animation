//
//  MinimalAnimation_2App.swift
//  Shared
//
//  Created by Balaji on 10/03/22.
//

import SwiftUI

@main
struct MinimalAnimation_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
