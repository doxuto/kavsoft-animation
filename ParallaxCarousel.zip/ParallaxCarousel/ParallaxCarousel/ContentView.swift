//
//  ContentView.swift
//  ParallaxCarousel
//
//  Created by Balaji on 11/08/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

#Preview {
    ContentView()
}
