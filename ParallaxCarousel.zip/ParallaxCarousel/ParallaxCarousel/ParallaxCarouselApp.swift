//
//  ParallaxCarouselApp.swift
//  ParallaxCarousel
//
//  Created by Balaji on 11/08/23.
//

import SwiftUI

@main
struct ParallaxCarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
