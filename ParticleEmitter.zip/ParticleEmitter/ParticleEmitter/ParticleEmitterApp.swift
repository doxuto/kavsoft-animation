//
//  ParticleEmitterApp.swift
//  ParticleEmitter
//
//  Created by Balaji on 22/04/23.
//

import SwiftUI

@main
struct ParticleEmitterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
