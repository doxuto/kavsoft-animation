//
//  MovieAppUIApp.swift
//  MovieAppUI
//
//  Created by Balaji on 07/08/22.
//

import SwiftUI

@main
struct MovieAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
