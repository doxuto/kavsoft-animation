//
//  AdvancedScrollApp.swift
//  Shared
//
//  Created by Balaji on 26/12/21.
//

import SwiftUI

@main
struct AdvancedScrollApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
