//
//  CircularSliderApp.swift
//  CircularSlider
//
//  Created by Balaji on 04/07/23.
//

import SwiftUI

@main
struct CircularSliderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
