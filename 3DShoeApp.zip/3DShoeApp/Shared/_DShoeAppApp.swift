//
//  _DShoeAppApp.swift
//  Shared
//
//  Created by Balaji on 28/08/22.
//

import SwiftUI

@main
struct _DShoeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//https://sketchfab.com/3d-models/nike-air-jordan-fd462c530d974f33a523d88a7562f1cf
