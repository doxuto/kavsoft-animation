//
//  AutoScrollingTabApp.swift
//  AutoScrollingTab
//
//  Created by Balaji on 11/03/23.
//

import SwiftUI

@main
struct AutoScrollingTabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
