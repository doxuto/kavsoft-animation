//
//  DynamicIslandRefrehableApp.swift
//  DynamicIslandRefrehable
//
//  Created by Balaji on 26/09/22.
//

import SwiftUI

@main
struct DynamicIslandRefrehableApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
