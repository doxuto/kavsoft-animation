//
//  WaterWaveApp.swift
//  Shared
//
//  Created by Balaji on 11/02/22.
//

import SwiftUI

@main
struct WaterWaveApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
