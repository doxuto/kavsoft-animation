//
//  NativeVideoPickerApp.swift
//  NativeVideoPicker
//
//  Created by Balaji on 13/04/23.
//

import SwiftUI

@main
struct NativeVideoPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
