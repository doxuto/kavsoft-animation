//
//  LottieRatingBarApp.swift
//  Shared
//
//  Created by Balaji on 11/11/21.
//

import SwiftUI

@main
struct LottieRatingBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
