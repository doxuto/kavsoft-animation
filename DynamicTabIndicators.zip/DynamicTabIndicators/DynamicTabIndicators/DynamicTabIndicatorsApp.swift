//
//  DynamicTabIndicatorsApp.swift
//  DynamicTabIndicators
//
//  Created by Balaji on 07/02/23.
//

import SwiftUI

@main
struct DynamicTabIndicatorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
