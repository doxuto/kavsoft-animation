//
//  SnapCarouselApp.swift
//  SnapCarousel
//
//  Created by Balaji on 10/02/23.
//

import SwiftUI

@main
struct SnapCarouselApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
