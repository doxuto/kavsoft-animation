//
//  WalkthroughAnimationApp.swift
//  WalkthroughAnimation
//
//  Created by Balaji on 15/06/23.
//

import SwiftUI

@main
struct WalkthroughAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
