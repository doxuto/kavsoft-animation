//
//  Secrets.swift
//  WidgetsFirebase
//
//  Created by Balaji on 30/09/21.
//

import SwiftUI

// Team ID
// Copy From developer portal....
let teamID = ""
