//
//  LoginKitApp.swift
//  LoginKit
//
//  Created by Balaji on 04/08/23.
//

import SwiftUI

@main
struct LoginKitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
