//
//  CustomTabBarApp.swift
//  Shared
//
//  Created by Balaji on 27/04/22.
//

import SwiftUI

@main
struct CustomTabBarApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
