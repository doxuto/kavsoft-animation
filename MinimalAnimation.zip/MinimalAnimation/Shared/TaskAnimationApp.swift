//
//  TaskAnimationApp.swift
//  Shared
//
//  Created by Balaji on 01/03/22.
//

import SwiftUI

@main
struct TaskAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
