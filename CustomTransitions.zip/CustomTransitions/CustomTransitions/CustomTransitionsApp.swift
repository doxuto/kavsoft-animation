//
//  CustomTransitionsApp.swift
//  CustomTransitions
//
//  Created by Balaji on 09/07/22.
//

import SwiftUI

@main
struct CustomTransitionsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
