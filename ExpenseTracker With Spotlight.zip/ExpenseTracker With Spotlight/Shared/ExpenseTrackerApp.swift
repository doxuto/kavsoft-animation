//
//  ExpenseTrackerApp.swift
//  Shared
//
//  Created by Balaji on 20/05/22.
//

import SwiftUI

@main
struct ExpenseTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
