//
//  ImageRenderer_PDFApp.swift
//  ImageRenderer-PDF
//
//  Created by Balaji on 25/06/22.
//

import SwiftUI

@main
struct ImageRenderer_PDFApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
