//
//  Isometric_AnimationApp.swift
//  Isometric Animation
//
//  Created by Balaji on 07/10/22.
//

import SwiftUI

@main
struct Isometric_AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
