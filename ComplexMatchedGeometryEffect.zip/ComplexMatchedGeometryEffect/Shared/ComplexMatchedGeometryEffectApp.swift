//
//  ComplexMatchedGeometryEffectApp.swift
//  Shared
//
//  Created by Balaji on 01/06/22.
//

import SwiftUI

@main
struct ComplexMatchedGeometryEffectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
