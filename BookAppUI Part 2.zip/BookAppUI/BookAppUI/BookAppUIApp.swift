//
//  BookAppUIApp.swift
//  BookAppUI
//
//  Created by Balaji on 05/03/23.
//

import SwiftUI

@main
struct BookAppUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
