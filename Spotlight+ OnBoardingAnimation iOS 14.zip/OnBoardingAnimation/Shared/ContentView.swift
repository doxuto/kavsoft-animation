//
//  ContentView.swift
//  Shared
//
//  Created by Balaji on 27/08/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {

        OnBoarding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
