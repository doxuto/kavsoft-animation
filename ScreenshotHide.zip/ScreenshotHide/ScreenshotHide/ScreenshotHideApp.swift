//
//  ScreenshotHideApp.swift
//  ScreenshotHide
//
//  Created by Balaji on 14/07/23.
//

import SwiftUI

@main
struct ScreenshotHideApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
