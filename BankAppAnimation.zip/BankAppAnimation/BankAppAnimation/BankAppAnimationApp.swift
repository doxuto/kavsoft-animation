//
//  BankAppAnimationApp.swift
//  BankAppAnimation
//
//  Created by Balaji on 13/04/23.
//

import SwiftUI

@main
struct BankAppAnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
