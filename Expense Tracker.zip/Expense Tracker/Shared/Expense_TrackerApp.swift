//
//  Expense_TrackerApp.swift
//  Shared
//
//  Created by Balaji on 18/03/22.
//

import SwiftUI

@main
struct Expense_TrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
