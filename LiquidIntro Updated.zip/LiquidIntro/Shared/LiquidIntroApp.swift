//
//  LiquidIntroApp.swift
//  Shared
//
//  Created by Balaji on 19/10/21.
//

import SwiftUI

@main
struct LiquidIntroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
