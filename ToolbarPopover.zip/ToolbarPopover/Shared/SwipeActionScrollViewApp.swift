//
//  SwipeActionScrollViewApp.swift
//  Shared
//
//  Created by Balaji on 13/10/21.
//

import SwiftUI

@main
struct SwipeActionScrollViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
