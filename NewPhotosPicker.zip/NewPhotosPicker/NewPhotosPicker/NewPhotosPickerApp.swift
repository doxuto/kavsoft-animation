//
//  NewPhotosPickerApp.swift
//  NewPhotosPicker
//
//  Created by Balaji on 24/06/22.
//

import SwiftUI

@main
struct NewPhotosPickerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
