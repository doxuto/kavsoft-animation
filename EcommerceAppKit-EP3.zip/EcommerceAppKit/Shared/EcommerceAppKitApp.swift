//
//  EcommerceAppKitApp.swift
//  Shared
//
//  Created by Balaji on 26/11/21.
//

import SwiftUI

@main
struct EcommerceAppKitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
